package com.controlproduct.controlproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
